/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_div_mod.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/18 14:13:09 by ishtiahm          #+#    #+#             */
/*   Updated: 2026/08/18 14:40:24 by ishtiahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_div_mod(int a, int b, int *div, int *mod)
{
	*div = a / b;
	*mod = a % b;
}
/*
#include <unistd.h>
int     main(void)
{
        int     a;
        int     b;
        int     div;
        int     mod;
        char    c;

        a = 10;
        b = 3;
        ft_div_mod(a, b, &div, &mod);
        c = div + '0';
        write(1, &c, 1);
        c = mod + '0';
        write(1, &c, 1);
        write(1, "\n", 1);
}*/
