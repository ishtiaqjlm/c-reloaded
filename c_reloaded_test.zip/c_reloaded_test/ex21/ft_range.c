/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_range.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/20 12:33:33 by ishtiahm          #+#    #+#             */
/*   Updated: 2026/08/20 13:02:51 by ishtiahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdlib.h>

int	*ft_range(int min, int max)
{
	int	size;
	int	*range;
	int	i;

	if (min >= max)
		return (NULL);
	size = max - min;
	range = malloc(sizeof(int) * size);
	if (range == NULL)
		return (NULL);
	i = 0;
	while (min < max)
	{
		range[i] = min;
		min++;
		i++;
	}
	return (range);
}
/*
#include <stdio.h>
int	main(void)
{
	int	min = 5;
	int	max = 10;
	int	*range;
	int	i = 0;

	range = ft_range(min, max);
	while(i < (max-min))
	{
		printf("Number is %d\n", range[i]);
		i++;
	}
	free(range);
	return (0);
}*/
