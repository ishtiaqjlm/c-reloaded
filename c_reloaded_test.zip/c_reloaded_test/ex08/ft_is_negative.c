/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_is_negative.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/18 12:36:03 by ishtiahm          #+#    #+#             */
/*   Updated: 2026/08/20 17:11:19 by ishtiahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
/*
#include <unistd.h>

void	ft_putchar(int	n)
{
	if(n >= 0)
		write(1, "P", 1);
	else
		write(1, "N", 1);
}
*/
void	ft_is_negative(int n)
{
	ft_putchar(n);
}
/*
int	main(void)
{
	int	i;
	i = 0;
	ft_is_negative(i);
	i = 1;
	ft_is_negative(i);
	i = -1;
	ft_is_negative(i);
	return (0);
}*/
