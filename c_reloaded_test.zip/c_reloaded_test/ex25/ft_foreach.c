/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_foreach.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/20 15:52:53 by ishtiahm          #+#    #+#             */
/*   Updated: 2026/08/20 16:56:11 by ishtiahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_foreach(int *tab, int length, void (*f)(int))
{
	int	i;

	i = 0;
	while (i < length)
	{
		f(tab[i]);
		i++;
	}
}
/*
#include <unistd.h>
void	ft_putnbr(int nb)
{
	char	negative;

	if (nb == -2147483648)
	{
		write(1, "-2147483648", 11);
		return ;
	}
	if (nb < 0)
	{
		negative = '-';
		write(1, &negative, 1);
		nb = -nb;
	}
	if (nb / 10 > 0)
	{
		ft_putnbr(nb / 10);
	}
	negative = (nb % 10) + '0';
	write(1, &negative, 1);
}

int	main(void)
{
	int tab[]={1,2,3};
	ft_foreach(tab, 3, &ft_putnbr);
}*/
