/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_iterative_factorial.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/18 14:44:34 by ishtiahm          #+#    #+#             */
/*   Updated: 2026/08/20 17:13:11 by ishtiahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_iterative_factorial(int nb)
{
	int	result;

	if (nb < 0)
		return (0);
	result = 1;
	while (nb > 0)
	{
		result = result * nb;
		nb --;
	}
	return (result);
}
/*
#include <stdio.h>
int	main(void)
{
	int	nb;
	int	result;

	nb = 5;
	result = ft_iterative_factorial(nb);
        printf("factorial of 5 is %d\n",result);	
}*/
