/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_display_file.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/21 14:05:54 by ishtiahm          #+#    #+#             */
/*   Updated: 2026/08/21 14:07:57 by ishtiahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <fcntl.h>
#include <unistd.h>

#define BUFFER_SIZE 4096

void	ft_putstr_stderr(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
		i++;
	write(2, str, i);
}

void	ft_display(char *file)
{
	int		fd;
	int		bytes_read;
	char	buffer[BUFFER_SIZE];

	fd = open(file, O_RDONLY);
	if (fd < 0)
	{
		ft_putstr_stderr("Cannot read file.\n");
		return ;
	}
	bytes_read = read(fd, buffer, BUFFER_SIZE);
	while (bytes_read > 0)
	{
		write(1, buffer, bytes_read);
		bytes_read = read(fd, buffer, BUFFER_SIZE);
	}
	close(fd);
}

int	main(int argc, char **argv)
{
	if (argc < 2)
	{
		ft_putstr_stderr("File name missing.\n");
		return (1);
	}
	if (argc > 2)
	{
		ft_putstr_stderr("Too many arguments.\n");
		return (1);
	}
	ft_display(argv[1]);
	return (0);
}
